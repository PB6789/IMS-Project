-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 02, 2017 at 10:23 PM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project`
--
CREATE DATABASE IF NOT EXISTS `project` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `project`;

-- --------------------------------------------------------

--
-- Table structure for table `mail`
--

CREATE TABLE `mail` (
  `id` int(11) NOT NULL,
  `to_id` varchar(255) NOT NULL,
  `from_id` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `r_id` int(1) NOT NULL,
  `d_id` int(1) NOT NULL,
  `t_id` int(1) NOT NULL,
  `file` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mail`
--

INSERT INTO `mail` (`id`, `to_id`, `from_id`, `subject`, `message`, `date`, `time`, `r_id`, `d_id`, `t_id`, `file`) VALUES
(1, '2', '3', 'FA', 'No msg', '2017-03-29', '18:55:11', 0, 0, 0, ''),
(2, '3', '2', 'po', 'zvsdvsdvsvbsv', '2017-03-29', '18:55:11', 0, 0, 0, ''),
(3, '2', '3', 'fg', 'adfasdfsaf', '2017-03-29', '18:56:46', 0, 0, 0, ''),
(4, '3', '2', 'fg', 'asfsgsfgbdfr', '2017-03-29', '18:56:46', 0, 0, 0, ''),
(5, '2', '3', 'cascascas', 'cascas', '2017-03-30', '01:27:54', 0, 0, 0, ''),
(7, '2', '3', 'dsfgefr', 'dfcsdgfvwsdv', '2017-03-30', '01:29:01', 0, 0, 0, ''),
(12, '2', '3', 'acacWDCREETY', 'SFDGERGWR', '2017-03-30', '01:48:31', 0, 0, 0, ''),
(13, '3', '2', 'adfwsdgfs', 'stjjhmgnfbdsfadfdgfhjmhjhngfbdvsvfdbgfnhgmn fgbvfsdbgfnhgmhhngfbdsfddfdbgf', '2017-03-30', '13:35:09', 0, 0, 0, ''),
(14, '3', '2', 'wertyuiopoijhgfdsasdfghjk', 'sdfghjkhmngfdsadfgnm,nbvc', '2017-03-30', '13:37:56', 0, 0, 0, 'uploaded/68_1490873876_fretboard.txt'),
(15, '3', '2', 'dshtyjukfghnfb', 'fjkhlj.g,hmgfvsdc', '2017-03-30', '13:43:11', 0, 0, 0, 'uploaded/57_1490874191_btproject.zip'),
(17, '2', '3', 'dsyj,jhfsda', 'ASSRETMJMTHNFGBDSA', '2017-03-30', '14:31:58', 0, 0, 0, ''),
(20, '2', '3', 'drtfgyjfgsfd', 'sgrdhtyjukhgfsdafghj,kbjhmgfbdsa', '2017-03-30', '14:40:15', 2, 0, 0, ''),
(26, '3', '2', 'afefhgfthrterwqeyethrjytj', 'waretsrydtjkguyjtrterwetrhjygytretrwgj', '2017-03-30', '20:46:56', 0, 0, 0, ''),
(27, '3', '2', 'wertyuiopoijhgfdsasdfghjk', 'etyyuitryewrqertykuut', '2017-03-31', '08:51:47', 0, 0, 0, 'uploaded/81_1490943107_sdasd.txt'),
(28, '3', '2', 'trstrdtrdtrdt', 'ytedtdtrdtrdtr', '2017-03-31', '09:46:30', 0, 0, 0, ''),
(29, '2', '3', 'Hello', 'wertyhjk', '2017-03-31', '09:51:40', 0, 0, 0, 'uploaded/47_1490946700_fretboard.txt');

-- --------------------------------------------------------

--
-- Table structure for table `record`
--

CREATE TABLE `record` (
  `uid` int(11) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `gender` varchar(6) NOT NULL,
  `password` varchar(255) NOT NULL,
  `skill` varchar(255) NOT NULL,
  `city` varchar(100) NOT NULL,
  `address` text NOT NULL,
  `ph_no` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `status` int(11) NOT NULL,
  `securityQ` varchar(255) NOT NULL,
  `ans` varchar(255) NOT NULL,
  `DOB` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `record`
--

INSERT INTO `record` (`uid`, `user_name`, `email`, `first_name`, `last_name`, `gender`, `password`, `skill`, `city`, `address`, `ph_no`, `image`, `status`, `securityQ`, `ans`, `DOB`) VALUES
(1, 'zvkvcbsjv@imsmail.com', 'pritam@basak.com', 'pritam', 'basak', 'male', '7c4a8d09ca3762af61e59520943dc26494f8941b', '', 'kolkata', 'nimta', '2147483647', '', 0, 'who is your favourite teacher?', 'me', '1999-12-31'),
(2, 'pritam@imsmail.com', 'pritam6789@gmail.com', 'pritam', 'basak', 'male', 'df2983700ffecb52e6649f0cb3981b66537083a4', '', 'kolkata', 'Salt Lake', '9433466983', '', 0, 'who is your favourite teacher?', 'me', '1999-07-19'),
(3, 'srtdry@imsmail.com', 'bobo', 'dyhdturtu', 'tyrtur', 'male', '7c4a8d09ca3762af61e59520943dc26494f8941b', '', 'kolkata', 'eryeru', '0', '', 0, 'what is the name of you pet?', 'dome', '2017-03-07');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `mail`
--
ALTER TABLE `mail`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `record`
--
ALTER TABLE `record`
  ADD PRIMARY KEY (`uid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `mail`
--
ALTER TABLE `mail`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;
--
-- AUTO_INCREMENT for table `record`
--
ALTER TABLE `record`
  MODIFY `uid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
