Developers:
1) Pritam Basak
2) Sonali Bhowmick
---------------------------------------------------------------------------------------------------------------------------
#Project: Internal Messaging System
#Features: inbox,outbox,trash,delete mail permanently,compose mail, register new user,reset fogotten password,Edit Profile,Change Password,User Login,
	   jquery ajax search,javascript validation.
#Concept Used: Developed using bootstrap,jquery and OOP concept in PHP with Mysql database. 
-----------------------------------------------------------------------------------------------------

Technical Details:
#Software:
#For Windows
1)xampp-win32-5.6.30-0-VC11-installer.exe
#For Linux
1)lampp with php 5.6.30

#PHP version 5.6.30
#mysql
#Apache 2
#phpmyadmin above version 4.
--------------------------------------------------------------------------------------------------------
Database Import:Import in phpmyadmin.
project->db->127.0.0.1.sql.
or
database->127.0.0.1.sql
or
execute the table structure-> table_structure.pdf in phpmyadmin SQL.