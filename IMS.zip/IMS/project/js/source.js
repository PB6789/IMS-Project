function logvar(){

var name = document.getElementById('name').value;
var pwd  = document.getElementById('pwd').value;
var flg = 0;

if (name==""){
			document.getElementById("n_error").innerHTML="Invalid Username";
			document.getElementById("n_error").style.color="blue";
			flg++;
		}
		else{
			document.getElementById("n_error").innerHTML="";
			flg=0;
		}

if (pwd=="" || pwd.length>6 || pwd.length<6){
			document.getElementById("p_error").innerHTML="Invalid Password";
			document.getElementById("p_error").style.color="blue";
			flg++;
		}

		else{
			document.getElementById("p_error").innerHTML="";
			flg=0;
		}
if(flg>0)
		{
			return false;
		}
		else
		{
			return true;
		}	

}

function fun()
{
	var user_name=document.getElementById("user_name").value;
	var chk=user_name.indexOf("@");
	
		if(chk>-1)
		{
			document.getElementById("l_user_name").innerHTML="invalid";
			document.getElementById("l_user_name").style.color="red";
			document.getElementById("valid_user").value="1";
			
		}
		
		else
		{
			document.getElementById("l_user_name").innerHTML="";
			document.getElementById("valid_user").innerHTML="0";
			
		}
}

function validation()
{
	var flag=0;
	var user_name=document.getElementById("user_name").value;
	var valid_user=document.getElementById("valid_user").value;
	
		if(user_name=="")
		{
			document.getElementById("l_user_name").innerHTML="invalid";
			document.getElementById("l_user_name").style.color="red";
			flag++;
		}
		
		else if(valid_user=="1")
		{
				document.getElementById("l_user_name").innerHTML="invalid";
				document.getElementById("l_user_name").style.color="red";
				flag++;
		}
		
		else
		{
			document.getElementById("l_user_name").innerHTML="";
			document.getElementById("valid_user").value="0";
		}

		
	var user_email=document.getElementById("email").value;
	var a=user_email.indexOf("@");
	var b=user_email.indexOf(".");
		
		if(user_email=="" || a==-1 || b<a+2 || b+2>=email.length)
		{
			document.getElementById("l_email").innerHTML="invalid";
			document.getElementById("l_email").style.color="red";
			flag++;
		}
		
		else
		{
			document.getElementById("l_email").innerHTML="";
		}

	var first_name=document.getElementById("first_name").value;
		if(	first_name=="" || !isNaN(first_name) )
		{
			document.getElementById("l_first_name").innerHTML="invalid";
			document.getElementById("l_first_name").style.color="red";
			flag++;
		}
		
		else
		{
			document.getElementById("l_first_name").innerHTML="";
		}

	var last_name=document.getElementById("last_name").value;
		if(last_name=="" || !isNaN(last_name) )
		{
			document.getElementById("l_last_name").innerHTML="invalid";
			document.getElementById("l_last_name").style.color="red";
			flag++;
		}
		
		else
		{
			document.getElementById("l_last_name").innerHTML="";
		}
	

	var gender1=document.getElementById("gender1").checked;
	var gender2=document.getElementById("gender2").checked;
		if(gender1==false && gender2==false)
		{
			document.getElementById("l_gender").innerHTML="invalid";
			document.getElementById("l_gender").style.color="red";
			flag++;
		}
		
		else
		{
			document.getElementById("l_gender").innerHTML="";
		}

	var password=document.getElementById("password").value;
		if(password=="" || password.length>6 || password.length<6 )
		{
			document.getElementById("l_password").innerHTML="invalid";
			document.getElementById("l_password").style.color="red";
			document.getElementById("l_valid").innerHTML="*password must have six charecter";				document.getElementById("l_valid").style.fontSize="12px";
			flag++;
		}
		else
		{
			document.getElementById("l_password").innerHTML="";
			document.getElementById("l_valid").innerHTML="";				
		}	
	
	var confirm_password=document.getElementById("confirm_password").value;
		if(confirm_password=="" || password!=confirm_password)
		{
			document.getElementById("l_confirm_password").innerHTML="invalid";
			document.getElementById("l_confirm_password").style.color="red";
			flag++;
		}
		
		else
		{
			document.getElementById("l_confirm_password").innerHTML="";
		}
	
	var city=document.getElementById("city").value;
		if(city=="" )
		{
			document.getElementById("l_city").innerHTML="invalid";
			document.getElementById("l_city").style.color="red";
			flag++;
		}
		
		else
		{
			document.getElementById("l_city").innerHTML="";
		}

	var address=document.getElementById("address").value;
		if(address=="")
		{
			document.getElementById("l_address").innerHTML="invalid";
			document.getElementById("l_address").style.color="red";
			flag++;
		}
		
		else
		{
			document.getElementById("l_address").innerHTML="";
		}

	var ph_no=document.getElementById("ph_no").value;
	var g=ph_no.length;
		if(ph_no=="" || isNaN(ph_no) || g>10 || g<10)
		{
			document.getElementById("l_ph_no").innerHTML="invalid";
			document.getElementById("l_ph_no").style.color="red";
			flag++;
		}
		
		else
		{
			document.getElementById("l_ph_no").innerHTML="";
		}
	
	
		
		var Q=document.getElementById("Q").value;
		var ans=document.getElementById("ans").value;
		if(Q=="" || ans=="")
		{
			document.getElementById("l_security").innerHTML="invalid";
			document.getElementById("l_security").style.color="red";
			flag++;
		}
		
		else
		{
			document.getElementById("l_security").innerHTML="";
		}
		
		var month=document.getElementById("month").value;
		var day=document.getElementById("day").value;
		var year=document.getElementById("year").value;
		if(month=="" || day=="" || year=="")
		{
			document.getElementById("l_DOB").innerHTML="invalid";
			document.getElementById("l_DOB").style.color="red";
			flag++;
		}
		
		else
		{
			document.getElementById("l_DOB").innerHTML="";
		}
		
		
		if(flag>0)
		{
			return false;
		}
		else
		{
			return true;
		}	
}

function other()
{
	var o=document.getElementById("city").value;
	if(o=='other')
	{
		document.getElementById("n").style.display="block";
		}
	else
	{
		document.getElementById("n").style.display="none";
	}
}

