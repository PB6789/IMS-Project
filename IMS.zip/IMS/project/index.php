<?php
session_start();
if(!isset($_SESSION['email']))
{
  ?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Account Log-in</title>
  <link rel="shortcut icon" href="favicon.ico" type="image/x-icon" />
  <link rel='stylesheet' href='jquery/jquery-ui-1.12.1/jquery-ui.css'>
  <link rel="stylesheet" href="css/style.css" media="screen" type="text/css" />
  <script type="text/javascript" src="js/source.js"></script>
</head>

<body style="background-image:url(images/blurred.jpg)">

  <div class="login-card">
    <center><img src="logo/ims.png" height="30px" align="middle"/></center>
    <h1>Log-in</h1><br>
  <form method="post" action="reg/log_action.php" onsubmit="return logvar()">
    <input type="text" name="user" id='name' placeholder="User email"><span id='n_error'></span>
    <input type="password" name="pass" id='pwd' placeholder="Password"><span id='p_error'></span>
    <input type="submit" name="login" class="login login-submit" value="login">
  </form>

  <div class="login-help">
    <a href="reg/form.php">Register</a> • <a href="reg/forgotpassword.php">Forgot Password</a>
  </div>
</div>
</body>
</html>
<?php
}
else if(isset($_SESSION['email'])){
 header('location:reg/index.php');
}
?>