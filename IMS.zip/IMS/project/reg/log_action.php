<?php
include "all.php";
$name = $_REQUEST['user'];
$pass = sha1($_REQUEST['pass']);
$obj = new A();
$var = $obj -> logaction($name,$pass);

if($var){
$rows = mysql_fetch_assoc($var);
$svar = $rows['user_name'];
session_start();
$_SESSION['email']=$svar;
header('Location: index.php');
}

?>