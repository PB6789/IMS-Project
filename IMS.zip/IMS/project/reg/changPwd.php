<?php
session_start();
if(isset($_SESSION['email']))
{	
	include "all.php";
	$id=$_SESSION['email'];
	$obj=new A();
	$row = $obj->fetchrecord($id);

?>

<!DOCTYPE html>
<html lang="en">
<?php include "head.php"; ?>
<body>
<?php include "header.php"; ?>
<script>
function pvalidation()
{
	var flag=0;
	var npwd=document.getElementById("npwd").value;
		if(npwd=="" || npwd.length>6 || npwd.length<6 )
		{
			document.getElementById("l_password").innerHTML="  invalid";
			document.getElementById("l_password").style.color="red";
			document.getElementById("l_valid").innerHTML="  *password must have six charecter";				document.getElementById("l_valid").style.fontSize="12px";
			flag++;
		}
		else
		{
			document.getElementById("l_password").innerHTML="";
			document.getElementById("l_valid").innerHTML="";				
		}	
	
	var cnpwd=document.getElementById("cnpwd").value;
		if(cnpwd=="" || npwd!=cnpwd)
		{
			document.getElementById("l_confirm_password").innerHTML="  invalid";
			document.getElementById("l_confirm_password").style.color="red";
			flag++;
		}
		
		else
		{
			document.getElementById("l_confirm_password").innerHTML="";
		}
		
	
		if(flag>0)
		{
			return false;
		}
		else
		{
			return true;
		}	
}
</script>
<div class="col-sm-8 text-right"> 
<form action="changPwdAction.php" method="post" onsubmit="return pvalidation()">
<table>
<th colspan="2" align="center">Change Profile Password</th>

<tr>
	<td>Current Password:</td>
	<td>
		<input type="password" name="cpwd" id="cpwd" size='40%'  placeholder="Enter your Current password" ><label id="l_cur_password"></label>
		
	</td>
</tr>
<tr>
	<td>New Password:</td>
	<td><input type="password" name="npwd" id="npwd" size='40%' placeholder="Enter your new password" ><label id="l_password"></label><label id="l_valid"></label></td>
</tr>

<tr>
	<td>Confirm New Password:</td>
	<td><input type="password" name="cnpwd" id="cnpwd" size='40%' placeholder="Confirm New Password" ><label id="l_confirm_password" ></label></td>
</tr>

<tr>
<td></td>
<td><input type="submit" value="Update Password"></td>

</tr>
</table>
</form>
</div>
	
<?php include "footer.php"; ?>
</body>
</html>

<?php
}
else{

	header('location:../index.php');
}

?>
