<?php
include "all.php";

$user_name=$_POST["user_name"]."@imsmail.com";
$email=$_POST["email"];
$first_name=$_POST["first_name"];
$last_name=$_POST["last_name"];
$gender=$_POST["gender"];
$password=sha1($_POST["password"]);
$confirm_password=sha1($_POST["confirm_password"]);
$city=$_POST["city"];
if($city=='other')
{
$city=$_POST["o_city"];
}

$address=$_POST["address"];
$ph_no=$_POST["ph_no"];


$securityQ=$_POST["Q"];
$securityAns=$_POST["ans"];
$DOB=$_POST["year"]."-".$_POST["month"]."-".$_POST["day"];

$obj=new A();

$sql=$obj->insert($user_name, $email, $first_name, $last_name, $gender, $password, $city, $address, $ph_no, $securityQ, $securityAns, $DOB);
		
			if($sql==true)
			{
			echo "<script>alert('Registration done')</script>";
			echo "<script>window.location.href='../index.php'</script>";	
			}
			
			else
			{
			echo "<script>alert('Registration incomplete')</script>";
			echo "<script>window.location.href='form.php'</script>";
			}

?>
