<?php
session_start();
if(isset($_SESSION['email']))
{
	include "all.php";
	$uid = $_SESSION['email'];
	$src = $_REQUEST['q'];
	$obj = new A();
	$row = $obj->fetchrecord();
	$qry = $obj->fetchtrashsrc($row['uid'],$src);
	$to = $obj->fetchassoc($qry);
?>

	<table class="table" id="myTable" class="tablesorter">
	<thead>
	<th>Select</th>
	<th>subject</th>
	<th>Message</th>
	<th>Date</th>
	<th>Time</th>
	<th>Delete</th>
	<th>Restore</th>
	</thead>
	<tbody>
	<?php
	/*echo $id;
	echo $str;
	echo "<pre>";
	print_r($to);
	echo "</pre>";
	*/
	
	
	for($i=0;$i<sizeof($to);$i++){
		
		$str1 = $to[$i]['r_id']==1?'inbox':'outbox';
		echo "<tr>";
		echo "<td><input type='checkbox'></td>";
		echo "<td>".$to[$i]['subject']."</td>";
		echo "<td>".$to[$i]['message']."</td>";
		echo "<td>".$to[$i]['date']."</td>";
		echo "<td>".$to[$i]['time']."</td>";
		echo "<td><a href=\"delete.php?id=".$to[$i]['id'].'&rid='.$to[$i]['r_id'].'&did='.$to[$i]['d_id']."\">Delete Permanently</a></td>";
		echo "<td><a href=\"restore.php?id=".$to[$i]['id'].'&rid='.$to[$i]['r_id'].'&did='.$to[$i]['d_id']."\">Move to ".$str1."</a></td>";
		echo "</tr>";
	}
	?>
	

<?php
}
else{

	header('location:../index.php');
}

?>
