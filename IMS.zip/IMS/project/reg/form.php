<html>
<head>
<title>Registration</title>
<meta charset="UTF-8">
<script src="js/source.js"></script>
<link rel="stylesheet" href="../css/style.css" media="screen" type="text/css" />
 <link rel='stylesheet' href='jquery/jquery-ui-1.12.1/jquery-ui.css'>
  <link rel="stylesheet" href="../css/style.css" media="screen" type="text/css" />
</head>
<body style="background-image:url(../images/blurred.jpg)">
<div class="login-card" style="width:50%">
<form action="fetch.php" method="post"  onsubmit="return validation()">
<table align="center">
<h1>User Registration</h1>

<tr>
	<td>User Name:</td>
	<td>
		<input type="text" name="user_name" id="user_name" onkeyup="fun()">@imsmail.com<label id="l_user_name"></label>
		<input type="hidden" name="valid_user" id="valid_user" value="0" >
	</td>
</tr>

<tr>
	<td>Your alternate email address:</td>
	<td><input type="text" name="email" id="email" placeholder="enter your email id"><label id="l_email"></label></td>
</tr>

<tr>
	<td>First Name:</td>
	<td><input type="text" name="first_name" id="first_name" placeholder="enter firstname"><label id="l_first_name"></label></td>
</tr>

<tr>
	<td>Last Name:</td>
	<td><input type="text" name="last_name" id="last_name" placeholder="enter surname"><label id="l_last_name"></label></td>
</tr>

<tr>
	<td>Gender:</td>
	<td><input type="radio" name="gender" id="gender1" value="male">Male
	<input type="radio" name="gender" id="gender2" value="female">Female<label id="l_gender"></label>
	</td>
</tr>

<tr>
	<td>Password:</td>
	<td><input type="password" name="password" id="password" placeholder="enter password"><label id="l_password"></label><br><label id="l_valid"></label></td>
</tr>

<tr>
	<td>Confirm Password:</td>
	<td><input type="password" name="confirm_password" id="confirm_password" placeholder="enter confirm password"><label id="l_confirm_password"></label></td>
</tr>

<tr>
	<td>City:</td>
	<td><select name="city" id="city" onchange="other()">
	<option value="">--select--</option>
	<option value="kolkata">Kolkata</option>
	<option value="mumbai">Mumbai</option>
	<option value="delhi">Delhi</option>
	<option value="other">Other</option>
	</select><label id="l_city"></label>
	<label id="n" style="display:none">Enter City:<input type="text" id="o_city" name="o_city"></label>
	</td>
</tr>

<tr>
	<td>Address:</td>
	<td><input type="textarea" name="address" id="address" placeholder="enter your address"><label id="l_address"></label></td>
</tr>

<tr>
	<td>Phone no:</td>
	<td><input type="text" name="ph_no" id="ph_no" placeholder="enter your ph no"><label id="l_ph_no"></label></td>
</tr>




<tr>
	<td>Security question:</td>
	<td><select id="Q" name="Q">
		<option value="">--select--</option>
		<option value="who is your favourite teacher?">who is your favourite teacher?</option>
		<option value="what is the name of you pet?">what is the name of you pet?</option>
		<option value="what is your mother's nick name?">what is your mother's nick name?</option>
		<option value="what is your father's birth date?">what is your father's birth date?</option>
		<option value="who is your favourite actor?">who is your favourite actor?</option>
		</select>
		</td>
		
</tr>
<tr>
<td>Answer:</td><td><input type="text" name="ans" id="ans"><label id="l_security"></label></td>
</tr>

<tr>
	<td>Birthday:</td>
	<td><select id="month" name="month">
		<option value="">Month</option>
		<option value="01">January</option>
		<option value="02">February</option>
		<option value="03">March</option>
		<option value="04">April</option>
		<option value="05">May</option>
		<option value="06">June</option>
		<option value="07">July</option>
		<option value="08">August</option>
		<option value="09">September</option>
		<option value="10">October</option>
		<option value="11">November</option>
		<option value="12">December</option>
		</select>
		<select name="day" id="day">
		<?php for($i=1;$i<=31;$i++)  { ?>
		<option value="<?php echo $i ?>" ><?php echo $i ?></option>
		<?php } ?></select>
		
		<select name="year" id="year">
			<?php $year=2017;
			for($i=1;$i<20;$i++) { ?>
			<option value="<?php echo $year ?>"> <?php echo $year ?> </option>
			<?php 
				$year = $year-1; 
			} ?>
		</select>
		
		<label id="l_DOB"></label></td>
</tr>

<tr><td>&nbsp;</td>&nbsp;<td></td></tr>	
<tr><td>&nbsp;</td>&nbsp;<td></td></tr>	

<tr>
<td></td>
<td><input type="submit" value="Submit" onsubmit="return" style="width:25%"> 
	<a href="../index.php" align="center" ><input type="button" value="  <- Back   " style="width:100%"></a></td>
</tr>


</table>
</form>
</form>
</div>
</body>
</html>
