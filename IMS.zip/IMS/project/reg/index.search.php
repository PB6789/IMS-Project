<?php
session_start();
if(isset($_SESSION['email']))
{
	include "all.php";
	$uid = $_SESSION['email'];
	$src = $_REQUEST['q'];
	$obj = new A();
	$row = $obj->fetchrecord();
	$qry = $obj->fetchinsrc($row['uid'],$src);
	$to = $obj->fetchassoc($qry);
?>
	<table class="table" id="myTable">
	<thead>
	<th>From</th>
	<th>Message</th>
	<th>Date</th>
	<th>Time</th>
	<th>Attachements</th>
	<th>Delete</th>
	</thead>
	<tbody>
	<?php
	for($i=0;$i<sizeof($to);$i++){
		$file = $to[$i]['file'];
		$fext = $file!=NULL?"File":"";
		$strr = explode('.',basename($_SERVER['PHP_SELF']));
		echo "<tr>";
		echo "<td>".$to[$i]['first_name']."</td>";
		echo "<td><a href=\"view.php?id=".$to[$i]['id'].'&str='.$strr[0]."\">".$to[$i]['message']."</a></td>";
		echo "<td>".$to[$i]['date']."</td>";
		echo "<td>".$to[$i]['time']."</td>";
		echo "<td><a href=".$to[$i]['file'].">".$fext."</a></td>";
		echo "<td><a href=\"trashaction.php?id=".$to[$i]['id'].'&str='.$strr[0]."\">Move to Trash</a></td>";
		echo "</tr>";
	}
	?>
	</tbody>
	</table>



<?php
}
else{

	header('location:../index.php');
}

?>
