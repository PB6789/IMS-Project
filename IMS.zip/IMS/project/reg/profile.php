<?php

include "all.php";
session_start();
	
$s_id=$_SESSION['s_id'];
$obj=new A();
$fetch=$obj->select($s_id);

?>

<table border="1" align="center">

	<tr>
	<th><a href="userLogout.php"><input type="button" value="logout"></a></th>
	<th colspan="12" align="center">User Profile</th>
	</tr>
	
	<tr>
	<td>Id</td>
	<td>Username</td>
	<td>Email</td>
	<td>Name</td>
	<td>Gender</td>
	<td>Skill</td>
	<td>City</td>
	<td>Address</td>
	<td>Ph No</td>
	<td>Image</td>
	<td>Status</td>
	<td align="center">Action</td>
	</tr>
			
	<tr>
	<td> <?php echo $fetch['id'] ?> </td>
	<td> <?php echo $fetch['user_name'] ?> </td>
	<td> <?php echo $fetch['email'] ?> </td>
	<td> <?php echo $fetch['first_name'] . " " . $fetch['last_name'] ?> </td>
	<td> <?php echo $fetch['gender'] ?> </td>
	<td> <?php echo $fetch['skill'] ?> </td>
	<td> <?php echo $fetch['city'] ?> </td>
	<td> <?php echo $fetch['address'] ?> </td>
	<td> <?php echo $fetch['ph_no'] ?> </td>
	<td> <img src="<?php echo $fetch['image'] ?>" height="80px" width="80px"> </td>
	<td> <?php echo $fetch['status'] ?> </td>
	<td align="center"><a href="change_password.php"><input type="button" value="Change Password"></a>
	<a href="change_image.php"><input type="button" value="Change Image"></a>
	<a href="edit.php"><input type="button" value="Edit Profile"></a></td>	
	</tr>
			
</table>	