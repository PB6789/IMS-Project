<?php
session_start();
include "all.php";
$user_name=$_SESSION['user_name'];
$password = sha1($_REQUEST['npwd']);

$obj= new A();
$res=$obj -> chngpwd($password,$user_name);
if($res)
{
	session_destroy();
	echo "<script>alert('Password Changed Successfully.')</script>";
	echo "<script>window.location.href='../index.php'</script>";
}
else
{	session_destroy();
	echo "<script>alert('Invalid Information given.')</script>";
	echo "<script>window.location.href='forgotpassword.php'</script>";
}


 ?>
