<?php
session_start();
if(isset($_SESSION['email']))
{	
	include "all.php";
	$id=$_SESSION['email'];
	$opwd=sha1($_REQUEST['cpwd']);
	$npwd=sha1($_REQUEST['npwd']);
	$cnpwd=sha1($_REQUEST['cnpwd']);
	$obj=new A();
	$row = $obj->fetchrecord($id);
	if($row['password']==$opwd)
	{
		$sql = $obj->chngpwd($npwd,$id);
		echo "<script>alert('Password has been updated')</script>";
		echo "<script>window.location.href='changPwd.php'</script>";	
	}
	else{
		echo "<script>alert('Current password not matched.')</script>";
		echo "<script>window.location.href='changPwd.php'</script>";	
	}

}
else{

	header('location:../index.php');
}

?>