<?php
session_start();
if(isset($_SESSION['email']))
{
include "all.php";
$per_page = 5;
if($_GET) {
	$page=$_GET['page'];
}
$start = ($page-1)*$per_page;
$obj = new A();
$row1 = $obj->fetchrecord();
$qry1 = $obj->fetchmail($row1['uid']);
$count = $obj->fetchnumrows($qry1);
$pages = ceil($count/$per_page);
$row = $obj->fetchrecord();
$qry = $obj->fetchmailpager($start,$per_page,$row['uid']);
$to = $obj->fetchassoc($qry);
?>
<!DOCTYPE html>
<html lang="en">
<?php include "head.php"; ?>
<body>
<?php include "header.php"; ?>
<div class="well">
<strong>Search:</strong><input type ="text" id="search" name="search" size='80%'>
</div>
	<div class="col-sm-8 text-left" id="here"> 
<table class="table" id="myTable">
	<thead>
	<th>From</th>
	<th>Message</th>
	<th>Date</th>
	<th>Time</th>
	<th>Attachements</th>
	<th>Delete</th>
	</thead>
	<tbody>
	<?php
	for($i=0;$i<sizeof($to);$i++){
		$file = $to[$i]['file'];
		$fext = $file!=NULL?"File":"";
		$strr = explode('.',basename($_SERVER['PHP_SELF']));
		echo "<tr>";
		echo "<td>".$to[$i]['first_name']."</td>";
		echo "<td><a href=\"view.php?id=".$to[$i]['id'].'&str='.$strr[0]."\">".$to[$i]['message']."</a></td>";
		echo "<td>".$to[$i]['date']."</td>";
		echo "<td>".$to[$i]['time']."</td>";
		echo "<td><a href=".$to[$i]['file'].">".$fext."</a></td>";
		echo "<td><a href=\"trashaction.php?id=".$to[$i]['id'].'&str='.$strr[0]."\">Move to Trash</a></td>";
		echo "</tr>";
	}
	?>
	</tbody>
	</table>
	 </div>
    <div id="pagination" class="col-sm-8 text-left">
		<ul class="pagination">
		<?php
		
		//Pagination Numbersclass="col-sm-8 text-left"
		for($i=1; $i<=$pages; $i++)
		{
			echo "<a id='pager' href=\"index.pager.php?page=".$i."\"> ".$i." </a>";

		}
		
		?>
		</ul>
	</div>	
<?php include "footer.php"; ?>
</body>
</html>

<?php
}
else{

	header('location:../index.php');
}

?>
