<?php
session_start();
if(isset($_SESSION['email']))
{
	include "all.php";
	$uid = $_SESSION['email'];
	$gid = $_REQUEST['id'];
	$rid = $_REQUEST['rid'];
	$did = $_REQUEST['did'];
	$obj = new A();
	$row = $obj->fetchrecord();
	
	//echo $row['uid']." ".$gid." ".$rid." ".$did." ".$uid;
	$rows = $obj->trashupdate($gid,$rid,$did,$row['uid']);
	
	header('location:trash.php');
	
}
else
{
	
	header('location:../index.php');
}
?>