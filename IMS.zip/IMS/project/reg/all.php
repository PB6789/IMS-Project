<?php
class A
{
	function __construct()
	{
		$connect=mysql_connect("localhost","root","") or die("Connection problem!");
		mysql_select_db("project",$connect);
		
		
	}
	function chngpwd($npwd,$id){
		$var = mysql_query("UPDATE `record` SET `password`='$npwd' WHERE `user_name`='$id'");
		return $var;
	}
	function check($user)
	{
		$chk=mysql_query("SELECT * FROM `record` WHERE `user_name`='$user' or `ph_no`='$user'");
		return mysql_num_rows($chk);
	}
	
	function log($user_name,$password)
	{
		$sql=mysql_query("SELECT * FROM `record` WHERE `user_name`='$user_name' AND `password`='$password'");
		return mysql_fetch_assoc($sql);
	}
	function update($user_name,$email,$first_name,$last_name,$gender,$city,$address,$ph_no,$s_id){
		
		$var = mysql_query("UPDATE `record` SET `user_name`='$user_name',`email`='$email',`first_name`='$first_name',`last_name`='$last_name',`gender`='$gender',`city`='$city',`address`='$address',`ph_no`='$ph_no' WHERE `user_name`='$s_id'");
		return $var;
	}
	
	function insert($user_name, $email, $first_name, $last_name, $gender, $password, $city, $address, $ph_no,$securityQ, $securityAns, $DOB)
	{
		$sqql = "INSERT INTO `record` (`user_name`,`email`,`first_name`,`last_name`,`gender`,`password`,`city`,`address`,`ph_no`,`status`,`securityQ`,`ans`,`DOB`) VALUES ('$user_name','$email','$first_name','$last_name','$gender','$password','$city','$address','$ph_no','0','$securityQ','$securityAns', '$DOB')";
		
		$sql=mysql_query($sqql) or die(mysql_error());
		//echo $sqql;
		return $sql;
	
	}
    
	function fetchrecord($uid=NULL){
		if($uid==NULL){
		$uid = $_SESSION['email'];
		}
		
		$var = mysql_query("SELECT * FROM `record` WHERE `user_name` = '$uid'");
		$rows = mysql_fetch_assoc($var);
		return $rows;	
		
	}
	//
	function fetchassoc($query){
		$result = array();
		while ($record = mysql_fetch_assoc($query)) {
         $result[] = $record;
		}
    	return $result;
    }
	//
    function fetchnumrows($query){
    	$result = mysql_num_rows($query);
    	return $result;
    }

	function fetchmail($uid){
		
		$query = mysql_query("SELECT * FROM `mail` LEFT JOIN `record` ON `record`.`uid`=`mail`.`from_id` WHERE `mail`.`to_id`='$uid' and `mail`.`r_id`= 0 ORDER BY `mail`.`date` DESC,`mail`.`time` DESC");
		return $query;
		
	}
	function fetchmailpager($start,$per_page,$uid){
		
		$query = mysql_query("SELECT * FROM `mail` LEFT JOIN `record` ON `record`.`uid`=`mail`.`from_id` WHERE `mail`.`to_id`='$uid' and `mail`.`r_id`= 0 ORDER BY `mail`.`date` DESC,`mail`.`time` DESC LIMIT $start,$per_page");
		return $query;
		
	}
	function fetchtofrm($uid){
		$rslt=mysql_fetch_assoc(mysql_query("SELECT `user_name` FROM `record` WHERE `uid`='$uid'"));
		return $rslt;
	}
	function fetchmsg($uid,$id,$str){
		
		if($str=="index"){
		$query = mysql_query("SELECT * FROM `mail` LEFT JOIN `record` ON `record`.`uid`=`mail`.`from_id` WHERE `mail`.`to_id`='$uid' and `mail`.`r_id`= 0  and `mail`.`id`= '$id' ORDER BY `mail`.`date`,`mail`.`time` DESC");
		}
		else if($str=="outbox" ){
		$query = mysql_query("SELECT * FROM `mail` LEFT JOIN `record` ON `record`.`uid`=`mail`.`to_id` WHERE `mail`.`from_id`='$uid' and `mail`.`d_id`= 0 and `mail`.`id`= '$id' ORDER BY `mail`.`date`,`mail`.`time` DESC");
		}
   		return $query;
	}

	function fetchoutbox($uid){
		
		$query = mysql_query("SELECT * FROM `mail` LEFT JOIN `record` ON `record`.`uid`=`mail`.`from_id` WHERE `mail`.`from_id`='$uid' and `mail`.`d_id`= 0  ORDER BY `mail`.`date` DESC,`mail`.`time` DESC");
		return $query;
		}
	
	function fetchoutpager($start,$per_page,$uid){
		
		$query = mysql_query("SELECT * FROM `mail` LEFT JOIN `record` ON `record`.`uid`=`mail`.`from_id` WHERE `mail`.`from_id`='$uid' and `mail`.`d_id`= 0  ORDER BY `mail`.`date` DESC,`mail`.`time` DESC LIMIT $start,$per_page");
		return $query;
		}
	function fetchtrash($uid){
		
		$query = mysql_query("SELECT * FROM `mail`  WHERE (`to_id`='$uid' or `from_id`='$uid') and (`r_id`=1 or `d_id`=1) ORDER BY `date`,`time` DESC");
    	return $query;
		}
	function movetotrash($uid,$gid,$str){
		
		if($str=="index"){
			$var=mysql_query("UPDATE `mail` SET `r_id`=1 WHERE `to_id`='$uid' and `id`='$gid'");
			
			}
		else if($str=="outbox"){
			$var=mysql_query("UPDATE `mail` SET `d_id`=1 WHERE `from_id`='$uid' and `id`='$gid'");
				
		}
		return $var;
	}
	function logaction($name,$pass){

		$sql = "SELECT * FROM `record` WHERE `user_name`='$name' AND `password`='$pass'";
		$var = mysql_query($sql) or die(mysql_error());
		return $var;
		}
		
	function restore($pid,$rid,$did,$uid){
		
		if($rid>0)
		{
			$var=mysql_query("UPDATE `mail` SET `r_id`=0 WHERE `to_id`='$uid' and `id`='$pid'");
			
		}
		else if($did>0){
			$var=mysql_query("UPDATE `mail` SET `d_id`=0 WHERE `from_id`='$uid' and `id`='$pid'");
			
		}
		return $var;
	}	
	function compose($toId,$fromId,$subject,$msg,$path,$date,$time)
	{
		
	return mysql_query("INSERT INTO `mail`(`to_Id`,`from_id`,`subject`,`message`,`file`,`date`,`time`,`r_id`,`d_id`) VALUES('$toId','$fromId','$subject','$msg','$path','$date','$time',0,0)")or die(mysql_error());		
	}
	function fetchinsrc($uid,$src){
		
		$query = mysql_query("SELECT * FROM `mail` LEFT JOIN `record` ON `record`.`uid`=`mail`.`from_id` WHERE `mail`.`to_id`='$uid' and `mail`.`r_id`= 0 and (`mail`.`message` LIKE '%$src%' OR `mail`.`date` LIKE '%$src%') ORDER BY `mail`.`date` DESC,`mail`.`time` DESC");
    return $query;
		
	}
	
	function fetchoutsrc($uid,$src){
		$query = mysql_query("SELECT * FROM `mail` LEFT JOIN `record` ON `record`.`uid`=`mail`.`from_id` WHERE `mail`.`from_id`='$uid' and `mail`.`d_id`= 0 and (`mail`.`message` LIKE '%$src%' OR `mail`.`date` LIKE '%$src%') ORDER BY `mail`.`date` DESC,`mail`.`time` DESC");
		
    return $query;
		
	}
	function fetchtrashsrc($uid,$src){
		
		$query = mysql_query("SELECT * FROM `mail`  WHERE (`to_id`='$uid' or `from_id`='$uid') and (`r_id`=1 or `d_id`=1) and (`message` LIKE '%$src%' OR `date` LIKE '%$src%') ORDER BY `date`,`time` DESC");
		
    return $query;
	}
	function logout(){
		session_start();
		unset($_SESSION['email']);
		$_SESSION = array();
		session_destroy();
		

	}
	function resetPwd($user_name,$ph_no,$securityQ,$ans){
		
		$var = mysql_query("SELECT * FROM `record` WHERE `user_name`='$user_name' and `ph_no`='$ph_no' and `securityQ`='$securityQ' and `ans`='$ans'");
		return $var;
	}
	function trashupdate($gid,$rid,$did,$uid){
		//$uid = $_SESSION['email'];
		if($rid>0 and $did>0)
		{  $var = mysql_query("DELETE FROM `mail` WHERE `id`='$gid' and (`to_id`='$uid' or `from_id`='$uid')");
			}
		else if($rid==0 and $did>0){
			$var = mysql_query("UPDATE `mail` SET `d_id`=2 WHERE `from_id`='$uid' and `id`='$gid'");
			}
		else if($rid>0 and $did==0){
			$var = mysql_query("UPDATE `mail` SET `r_id`=2 WHERE `to_id`='$uid' and `id`='$gid'");
			}
		return $var;
	}
}

?>
