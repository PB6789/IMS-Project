  </div>
</div>
<footer class="container-fluid text-center">
Account : <?php echo $row['user_name']; ?>
</footer>

