<?php
session_start();
if(isset($_SESSION['email']))
{
	include "all.php";
	$uid = $_SESSION['email'];
	$gid = $_REQUEST['id'];
	$str = $_REQUEST['str'];
	$obj = new A();
	$row = $obj->fetchrecord();
	$trs = $obj->movetotrash($row['uid'],$gid,$str);
	if($str=="index" && $trs)
	{
		header('location:index.php');
	}
	else if($str=="outbox" && $trs){
		
		header('location:outbox.php');
	}
	
}
else{

	header('location:../index.php');
}

?>