<?php
session_start();
if(isset($_SESSION['email']))
{	
	include "all.php";
	$id=$_SESSION['email'];
	$obj=new A();
	$row = $obj->fetchrecord($id);

?>

<!DOCTYPE html>
<html lang="en">
<?php include "head.php"; ?>
<body>
<?php include "header.php"; ?>
<script>
function mvalidation()
{
	var flag=0;
	var user_name=document.getElementById("user_name").value;
	var valid_user=document.getElementById("valid_user").value;
	
		if(user_name=="")
		{
			document.getElementById("l_user_name").innerHTML="  invalid";
			document.getElementById("l_user_name").style.color="red";
			flag++;
		}
		
		else if(valid_user=="1")
		{
				document.getElementById("l_user_name").innerHTML="  invalid";
				document.getElementById("l_user_name").style.color="red";
				flag++;
		}
		
		else
		{
			document.getElementById("l_user_name").innerHTML="";
			document.getElementById("valid_user").value="0";
		}

		
	var user_email=document.getElementById("email").value;
	var a=user_email.indexOf("@");
	var b=user_email.indexOf(".");
		
		if(user_email=="" || a==-1 || b<a+2 || b+2>=email.length)
		{
			document.getElementById("l_email").innerHTML="  invalid";
			document.getElementById("l_email").style.color="red";
			flag++;
		}
		
		else
		{
			document.getElementById("l_email").innerHTML="";
		}

	var first_name=document.getElementById("first_name").value;
		if(	first_name=="" || !isNaN(first_name) )
		{
			document.getElementById("l_first_name").innerHTML="  invalid";
			document.getElementById("l_first_name").style.color="red";
			flag++;
		}
		
		else
		{
			document.getElementById("l_first_name").innerHTML="";
		}

	var last_name=document.getElementById("last_name").value;
		if(last_name=="" || !isNaN(last_name) )
		{
			document.getElementById("l_last_name").innerHTML="  invalid";
			document.getElementById("l_last_name").style.color="red";
			flag++;
		}
		
		else
		{
			document.getElementById("l_last_name").innerHTML="";
		}
	

	var gender1=document.getElementById("gender1").checked;
	var gender2=document.getElementById("gender2").checked;
		if(gender1==false && gender2==false)
		{
			document.getElementById("l_gender").innerHTML="  invalid";
			document.getElementById("l_gender").style.color="red";
			flag++;
		}
		
		else
		{
			document.getElementById("l_gender").innerHTML="";
		}

	
	
	var city=document.getElementById("city").value;
		if(city=="" )
		{
			document.getElementById("l_city").innerHTML="  invalid";
			document.getElementById("l_city").style.color="red";
			flag++;
		}
		
		else
		{
			document.getElementById("l_city").innerHTML="";
		}

	var address=document.getElementById("address").value;
		if(address=="")
		{
			document.getElementById("l_address").innerHTML="  invalid";
			document.getElementById("l_address").style.color="red";
			flag++;
		}
		
		else
		{
			document.getElementById("l_address").innerHTML="";
		}

	var ph_no=document.getElementById("ph_no").value;
	var g=ph_no.length;
		if(ph_no=="" || isNaN(ph_no) || g>10 || g<10)
		{
			document.getElementById("l_ph_no").innerHTML="  invalid";
			document.getElementById("l_ph_no").style.color="red";
			flag++;
		}
		
		else
		{
			document.getElementById("l_ph_no").innerHTML="";
		}
	
	
		
		
		
		var month=document.getElementById("month").value;
		var day=document.getElementById("day").value;
		var year=document.getElementById("year").value;
		if(month=="" || day=="" || year=="")
		{
			document.getElementById("l_DOB").innerHTML="  invalid";
			document.getElementById("l_DOB").style.color="red";
			flag++;
		}
		
		else
		{
			document.getElementById("l_DOB").innerHTML="";
		}
		
		
		if(flag>0)
		{
			return false;
		}
		else
		{
			return true;
		}	
}
</script>
<div class="col-sm-8 text-right"> 
<form action="editAction.php" method="post"  onsubmit="return mvalidation()">
<table>
<th colspan="2" align="center">User Registration</th>

<tr>
	<td>User Name:</td>
	<td>
		<input type="text" name="user_name" id="user_name" onkeyup="return fun()" value="<?php echo $row ['user_name'];?>" disabled ><label id="l_user_name"></label>
		<input type="hidden" name="valid_user" id="valid_user" value="0" >
	</td>
</tr>

<tr>
	<td>Your alternate email address:</td>
	<td><input type="text" name="email" id="email" placeholder="enter your email id" value="<?php echo $row ['email'];?>"><label id="l_email"></label></td>
</tr>

<tr>
	<td>First Name:</td>
	<td><input type="text" name="first_name" id="first_name" placeholder="enter firstname" value="<?php echo $row ['first_name'];?>"><label id="l_first_name"></label></td>
</tr>

<tr>
	<td>Last Name:</td>
	<td><input type="text" name="last_name" id="last_name" placeholder="enter surname" value="<?php echo $row ['last_name'];?>"><label id="l_last_name"></label></td>
</tr>

<tr>
	<td>Gender:</td>
	<td><input type="radio" name="gender" id="gender1" value="male" <?php echo ($row['gender']=='male')? 'checked':' ' ?> >Male
	<input type="radio" name="gender" id="gender2" value="female" <?php echo ($row['gender']=='female')? 'checked':' ' ?>>Female<label id="l_gender"></label>
	</td>
</tr>

<tr>
	<td>City:</td>
	<td><select name="city" id="city" onchange="other()">
	<option value="">--select--</option>
	<option value="kolkata" <?php echo ($row['city']=='kolkata')? 'selected':' ' ?> >Kolkata</option>
	<option value="mumbai" <?php echo ($row['city']=='mumbai')? 'selected':' ' ?> >Mumbai</option>
	<option value="delhi" <?php echo ($row['city']=='delhi')? 'selected':' ' ?> >Delhi</option>
	<option value="other" <?php echo ($row['city']!='kolkata' && $fetch['city']!='mumbai' && $fetch['city']!='delhi' && $fetch['city']!="")? 'selected':' ' ?> >Other</option>
	</select><label id="l_city"></label>
	
	<?php if($row['city']!='kolkata' && $row['city']!='mumbai' && $row['city']!='delhi' && $row['city']!="") { ?>
	<label id="n" style="display:block">Enter City:<input type="text" id="o_city" name="o_city" value="<?php echo $row['city'] ?>" ></label>
	<?php } else { ?><label id="n" style="display:none">Enter City:<input type="text" id="o_city" name="o_city"></label> <?php } ?>
	</td>
</tr>

<tr>
	<td>Address:</td>
	<td><input type="textarea" name="address" id="address" placeholder="enter your address" value="<?php echo $row['address'] ?>" ><label id="l_address"></label></td>
</tr>

<tr>
	<td>Phone no:</td>
	<td><input type="text" name="ph_no" id="ph_no" placeholder="enter your ph no" value="<?php echo $row['ph_no'] ?>" ><label id="l_ph_no"></label></td>
</tr>


	<td>Birthday:</td>
	<td><select id="month" name="month">
		<option value="">Month</option>
		<option value="01">January</option>
		<option value="02">February</option>
		<option value="03">March</option>
		<option value="04">April</option>
		<option value="05">May</option>
		<option value="06">June</option>
		<option value="07">July</option>
		<option value="08">August</option>
		<option value="09">September</option>
		<option value="10">October</option>
		<option value="11">November</option>
		<option value="12">December</option>
		</select>
		<select name="day" id="day">
		<?php for($i=1;$i<=31;$i++)  { ?>
		<option value="<?php echo $i ?>" ><?php echo $i ?></option>
		<?php } ?></select>
		
		<select name="year" id="year">
			<?php $year=2017;
			for($i=1;$i<50;$i++) { ?>
			<option value="<?php echo $year ?>"> <?php echo $year ?> </option>
			<?php 
				$year = $year-1; 
			} ?>
		</select>
		
		<label id="l_DOB"></label></td>
</tr> 
		

<tr>
<td></td>
<td align="center"><input type="submit" value="Update Information" onsubmit="return"></td>

</tr>
</table>
</form>
</div>
	
<?php include "footer.php"; ?>
</body>
</html>

<?php
}
else{

	header('location:../index.php');
}

?>
