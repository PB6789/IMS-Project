<?php
session_start();
if(isset($_SESSION['email']))
{
	include "all.php";
	$uid = $_SESSION['email'];
	//$id = $_REQUEST['id'];
	//$str = $_REQUEST['str'];
	if ($_REQUEST){
	$rst = $_REQUEST['usr'];
	}
	else{
		$rst="";
	}
		
	$obj = new A();
	$row = $obj->fetchrecord();
	//$to = $obj->fetchmsg($row['uid'],$id,$str);
	
?>
<!DOCTYPE html>
<html lang="en">
<?php include "head.php"; ?>
<body>

<?php include "header.php"; ?>
<div class="col-sm-8 text-left"> 
<h4 align="left">Compose a New mail</h4>
<form action="composeMailAction.php" method="post"  enctype="multipart/form-data" onsubmit="return mailValidation()" >
<table>
<tr>
	<td>
		<input type="text" id="toId" name="toId" size="100%" placeholder="To" value="<?php echo $rst;?>"><label id="l"></label>
	</td>
</tr>

<tr>
	<td><input type="text" id="subject" name="subject" size="100%" placeholder="Subject">
	</td>
</tr>

<tr>
	<td><textarea name="message" rows="10"  cols="100" name="message" id="message" style="resize:none"></textarea></td>
</tr>
		
<tr>
	<td><input type="file" name="pic" id="pic"></td>
</tr>

<tr>
	<td><input type="submit" value="Send"></td>
</tr>
</table>
</form>
</div>
	
<?php include "footer.php"; ?>
</body>
</html>

<?php
}
else{

	header('location:../index.php');
}

?>
