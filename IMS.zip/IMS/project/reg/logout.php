<?php

include "all.php";
$obj = new A();
$obj -> logout();
header('Location: ../index.php');

?>