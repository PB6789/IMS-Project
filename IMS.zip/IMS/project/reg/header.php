<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="index.php">
	
	</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
		
	 <ul class="nav navbar-nav">
        <li class="active" ><a href="index.php">Welcome <?php echo $row['first_name']; ?></a></li>
		<li class="active" ><a href="editProfile.php">Edit Profile</a></li>
		<li class="active" ><a href="changPwd.php">Change Password</a></li>
        
		</ul>
      <ul class="nav navbar-nav navbar-right">
        <li><a href="logout.php"><span class="glyphicon glyphicon-log-in"></span> Logout</a></li>
      </ul>
    </div>
  </div>
</nav>
  
<div class="container-fluid text-center">    
  <div class="row content">
    <div class="col-sm-2 sidenav">
	 <p><a href="composeMail.php">Compose</a></p>
	  <p><a href="index.php">inbox</a></p>
      <p><a href="outbox.php">outbox</a></p>
      <p><a href="trash.php">trash</a></p>
	 
    </div>

