<?php

include "all.php";
session_start();

$user_name=$_POST["user_name"]."@imsmail.com";
$password=sha1($_POST["password"]);

$obj=new A();
$sql_fetch=$obj->log($user_name,$password);

if($sql_fetch)
{
	echo "<script>alert('successfull login')</script>";
	//echo "<script>window.location.href='profile.php'</script>";
}

else
{
	echo "<script>alert('unsuccessfull login')</script>";
	//echo "<script>window.location.href='log.php'</script>";
}


$_SESSION['s_id']=$sql_fetch['id'];

?>