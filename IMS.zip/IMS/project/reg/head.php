<head>
<title>
<?php
$arr = array("Home"=>"index.php","Outbox"=>"outbox.php","Trash"=>"trash.php","View"=>"view.php");
foreach($arr as $key=>$value)
{
	if(basename($_SERVER['PHP_SELF']) == $value)
	{
		echo $key;
	}
}
?>
</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
  <link rel="shortcut icon" href="../favicon.ico" type="image/x-icon" />
  <script src="jquery/jquery.min.js"></script>
  <link rel="stylesheet" href="js/jquery-ui-1.12.1/jquery-ui.css">
  <script src="js/jquery-ui-1.12.1/jquery-ui.js"></script>
  <script src="bootstrap/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="jquery/jquery-ui-theme/themes/black-tie/jquery-ui.css">
  <script src="jquery/jquery-ui-1.12.1/jquery-ui.js"></script>
	<link rel="stylesheet" href="../css/custom.css">
  <link rel="stylesheet" href="css/custom.css">  
  <script type="text/javascript" src="js/jquery_pagination.js"></script>
<!--link rel='stylesheet' href='css/style.css' type='text/css' /-->
  <script src="js/source.js"></script>
</head>

