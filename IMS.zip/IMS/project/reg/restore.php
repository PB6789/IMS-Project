<?php
session_start();
if(isset($_SESSION['email']))
{
	include "all.php";
	$pid = $_REQUEST['id'];
	$rid = $_REQUEST['rid'];
	$did = $_REQUEST['did'];
	$obj = new A();
	$row = $obj->fetchrecord();
	$res=$obj -> restore($pid,$rid,$did,$row['uid']);
	
	header('location:trash.php');
	
}
else
{
	
	header('location:../index.php');
}
?>