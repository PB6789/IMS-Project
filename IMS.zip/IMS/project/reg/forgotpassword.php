<html>
<script>
	function validation() {
		var user_name=document.getElementById("user_name").value;
		var a=user_name.indexOf("@");
			if(user_name=="" || a>-1) {
			document.getElementById('lp').innerHTML="invalid";
			document.getElementById('lp').style.color="red";
			return false;
		}
		var phn_no=document.getElementById("phn_no").value;
		
			if(phn_no.length>10 || phn_no.length<10) {
			document.getElementById('pt').innerHTML="invalid";
			document.getElementById('pt').style.color="red";
			return false;
		}
		var Qt=document.getElementById("Qt").value;
		
			if(Qt=="") {
			document.getElementById('qs').innerHTML="invalid";
			document.getElementById('qs').style.color="red";
			return false;
		}
		var ans=document.getElementById("ans").value;
		
			if(ans=="") {
			document.getElementById('asecurity').innerHTML="invalid";
			document.getElementById('asecurity').style.color="red";
			return false;
		}
	}
</script>
<body>
<form action="forgotpasswordaction.php" method="post" onsubmit="return validation()">
	<table border="1" align="center">
		<tr>
			<td>Enter your username:</td>
			<td><input type="text" name="user_name" id="user_name">
			<label id="lp"></label></td>
		</tr>
		<tr>
			<td>Enter your Phone No.:</td>
			<td><input type="number" name="phn_no" id="phn_no">
			<label id="pt"></label></td>
		</tr>
		<tr>
	<td>Security question:</td>
	<td><select id="Qt" name="Qt">
		<option value="">--select--</option>
		<option value="who is your favourite teacher?">who is your favourite teacher?</option>
		<option value="what is the name of you pet?">what is the name of you pet?</option>
		<option value="what is your mother's nick name?">what is your mother's nick name?</option>
		<option value="what is your father's birth date?">what is your father's birth date?</option>
		<option value="who is your favourite actor?">who is your favourite actor?</option>
		</select>
		<label id="qs"></label>
		</td>
		
		
</tr>
<tr>
<td>Answer:</td><td><input type="text" name="ans" id="ans"><label id="asecurity"></label></td>
</tr>
		<tr>
			<td align="center"><input type="submit" value="submit"></td>
		</tr>
	</table>
	
</form>
</body>
</html>