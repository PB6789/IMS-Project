<?php
session_start();
?>

<html>
<script>
	function validation() {
		var npwd=document.getElementById("npwd").value;
		
			if(npwd.length>6 || npwd.length<6) {
			document.getElementById('np').innerHTML="invalid.Enter 6 character Password";
			document.getElementById('np').style.color="red";
			return false;
		}
		var cnpwd=document.getElementById("cnpwd").value;
		
			if(cnpwd != npwd) {
			document.getElementById('cnp').innerHTML="Password Does not match";
			document.getElementById('cnp').style.color="red";
			return false;
		}
		
	}
</script>
<body>
<form action="resetPwdaction.php" method="post" onsubmit="return validation()">
	<table border="1" align="center">
		<tr>
			<td>Enter New Password:</td>
			<td><input type="password" name="npwd" id="npwd">
			<label id="np"></label></td>
		</tr>
		<tr>
			<td>Confirm New Password:</td>
			<td><input type="password" name="cnpwd" id="cnpwd">
			<label id="cnp"></label></td>
		</tr>
	
		<tr>
			<td align="center"><input type="submit" value="Reset Password"></td>
		</tr>
	</table>
	
</form>
</body>
</html>