<?php
include "all.php";
$user_name=$_REQUEST['user_name']."@imsmail.com";
$ph_no=$_REQUEST['phn_no'];
$securityQ=$_REQUEST['Qt'];
$ans=$_REQUEST['ans'];

$obj= new A();
$res=$obj -> resetPwd($user_name,$ph_no,$securityQ,$ans);
if($res)
{
	session_start();
	$_SESSION['user_name']=$user_name;
	echo "<script>window.location.href='resetPwd.php'</script>";
}
else
{
	echo "<script>alert('Invalid Information given.')</script>";
	echo "<script>window.location.href='forgotpassword.php'</script>";
}


 ?>
