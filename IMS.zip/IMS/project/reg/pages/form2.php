<html>
<head>
<title>Registration</title>
<script>
function fun()
{
	var user_name=document.getElementById("user_name").value;
	var chk=user_name.indexOf("@");
	
		if(chk>-1)
		{
			document.getElementById("l_user_name").innerHTML="invalid";
			document.getElementById("l_user_name").style.color="red";
			document.getElementById("valid_user").value="1";
			
		}
		
		else
		{
			document.getElementById("l_user_name").innerHTML="";
			document.getElementById("valid_user").innerHTML="0";
			
		}
}

function validation()
{
	var flag=0;
	var user_name=document.getElementById("user_name").value;
	var valid_user=document.getElementById("valid_user").value;
	
		if(user_name=="")
		{
			document.getElementById("l_user_name").innerHTML="invalid";
			document.getElementById("l_user_name").style.color="red";
			flag++;
		}
		
		else if(valid_user=="1")
		{
				document.getElementById("l_user_name").innerHTML="invalid";
				document.getElementById("l_user_name").style.color="red";
				flag++;
		}
		
		else
		{
			document.getElementById("l_user_name").innerHTML="";
			document.getElementById("valid_user").value="0";
		}

		
	var user_email=document.getElementById("email").value;
	var a=user_email.indexOf("@");
	var b=user_email.indexOf(".");
		
		if(user_email=="" || a==-1 || b<a+2 || b+2>=email.length)
		{
			document.getElementById("l_email").innerHTML="invalid";
			document.getElementById("l_email").style.color="red";
			flag++;
		}
		
		else
		{
			document.getElementById("l_email").innerHTML="";
		}

	var first_name=document.getElementById("first_name").value;
		if(	first_name=="" || !isNaN(first_name) )
		{
			document.getElementById("l_first_name").innerHTML="invalid";
			document.getElementById("l_first_name").style.color="red";
			flag++;
		}
		
		else
		{
			document.getElementById("l_first_name").innerHTML="";
		}

	var last_name=document.getElementById("last_name").value;
		if(last_name=="" || !isNaN(last_name) )
		{
			document.getElementById("l_last_name").innerHTML="invalid";
			document.getElementById("l_last_name").style.color="red";
			flag++;
		}
		
		else
		{
			document.getElementById("l_last_name").innerHTML="";
		}
	

	var gender1=document.getElementById("gender1").checked;
	var gender2=document.getElementById("gender2").checked;
		if(gender1==false && gender2==false)
		{
			document.getElementById("l_gender").innerHTML="invalid";
			document.getElementById("l_gender").style.color="red";
			flag++;
		}
		
		else
		{
			document.getElementById("l_gender").innerHTML="";
		}

	var password=document.getElementById("password").value;
		if(password=="" || password.length>6 || password.length<6 )
		{
			document.getElementById("l_password").innerHTML="invalid";
			document.getElementById("l_password").style.color="red";
			document.getElementById("l_valid").innerHTML="*password must have six charecter";				document.getElementById("l_valid").style.fontSize="12px";
			flag++;
		}
		else
		{
			document.getElementById("l_password").innerHTML="";
			document.getElementById("l_valid").innerHTML="";				
		}	
	
	var confirm_password=document.getElementById("confirm_password").value;
		if(confirm_password=="" || password!=confirm_password)
		{
			document.getElementById("l_confirm_password").innerHTML="invalid";
			document.getElementById("l_confirm_password").style.color="red";
			flag++;
		}
		
		else
		{
			document.getElementById("l_confirm_password").innerHTML="";
		}
	
	var city=document.getElementById("city").value;
		if(city=="" )
		{
			document.getElementById("l_city").innerHTML="invalid";
			document.getElementById("l_city").style.color="red";
			flag++;
		}
		
		else
		{
			document.getElementById("l_city").innerHTML="";
		}

	var address=document.getElementById("address").value;
		if(address=="")
		{
			document.getElementById("l_address").innerHTML="invalid";
			document.getElementById("l_address").style.color="red";
			flag++;
		}
		
		else
		{
			document.getElementById("l_address").innerHTML="";
		}

	var ph_no=document.getElementById("ph_no").value;
	var g=ph_no.length;
		if(ph_no=="" || isNaN(ph_no) || g>10 || g<10)
		{
			document.getElementById("l_ph_no").innerHTML="invalid";
			document.getElementById("l_ph_no").style.color="red";
			flag++;
		}
		
		else
		{
			document.getElementById("l_ph_no").innerHTML="";
		}
	
	var image=document.getElementById("pic").value;
		if(image=="")
		{
			document.getElementById("l_pic").innerHTML="invalid";
			document.getElementById("l_pic").style.color="red";
			flag++;
		}
		
		else
		{
			document.getElementById("l_pic").innerHTML="";
		}
		
		var Q=document.getElementById("Q").value;
		var ans=document.getElementById("ans").value;
		if(Q=="" || ans=="")
		{
			document.getElementById("l_security").innerHTML="invalid";
			document.getElementById("l_security").style.color="red";
			flag++;
		}
		
		else
		{
			document.getElementById("l_security").innerHTML="";
		}
		
		var month=document.getElementById("month").value;
		var day=document.getElementById("day").value;
		var year=document.getElementById("year").value;
		if(month=="" || day=="" || year=="")
		{
			document.getElementById("l_DOB").innerHTML="invalid";
			document.getElementById("l_DOB").style.color="red";
			flag++;
		}
		
		else
		{
			document.getElementById("l_DOB").innerHTML="";
		}
		
		
		if(flag>0)
		{
			return false;
		}
		else
		{
			return true;
		}	
}

function other()
{
	var o=document.getElementById("city").value;
	if(o=='other')
	{
		document.getElementById("n").style.display="block";
		}
	else
	{
		document.getElementById("n").style.display="none";
	}
}

</script>
</head>

<body>
<form action="fetch.php" method="post" enctype="multipart/form-data" onsubmit="return validation()">
<table border="1" align="center">
<th colspan="2" align="center">User Registration</th>

<tr>
	<td>User Name:</td>
	<td>
		<input type="text" name="user_name" id="user_name" onkeyup="fun()">@imsmail.com<label id="l_user_name"></label>
		<input type="hidden" name="valid_user" id="valid_user" value="0" >
	</td>
</tr>

<tr>
	<td>Your alternate email address:</td>
	<td><input type="text" name="email" id="email" placeholder="enter your email id"><label id="l_email"></label></td>
</tr>

<tr>
	<td>First Name:</td>
	<td><input type="text" name="first_name" id="first_name" placeholder="enter firstname"><label id="l_first_name"></label></td>
</tr>

<tr>
	<td>Last Name:</td>
	<td><input type="text" name="last_name" id="last_name" placeholder="enter surname"><label id="l_last_name"></label></td>
</tr>

<tr>
	<td>Gender:</td>
	<td><input type="radio" name="gender" id="gender1" value="male">Male
	<input type="radio" name="gender" id="gender2" value="female">Female<label id="l_gender"></label>
	</td>
</tr>

<tr>
	<td>Password:</td>
	<td><input type="password" name="password" id="password" placeholder="enter password"><label id="l_password"></label><br><label id="l_valid"></label></td>
</tr>

<tr>
	<td>Confirm Password:</td>
	<td><input type="password" name="confirm_password" id="confirm_password" placeholder="enter confirm password"><label id="l_confirm_password"></label></td>
</tr>

<tr>
	<td>City:</td>
	<td><select name="city" id="city" onchange="other()">
	<option value="">--select--</option>
	<option value="kolkata">Kolkata</option>
	<option value="mumbai">Mumbai</option>
	<option value="delhi">Delhi</option>
	<option value="other">Other</option>
	</select><label id="l_city"></label>
	<label id="n" style="display:none">Enter City:<input type="text" id="o_city" name="o_city"></label>
	</td>
</tr>

<tr>
	<td>Address:</td>
	<td><input type="textarea" name="address" id="address" placeholder="enter your address"><label id="l_address"></label></td>
</tr>

<tr>
	<td>Phone no:</td>
	<td><input type="text" name="ph_no" id="ph_no" placeholder="enter your ph no"><label id="l_ph_no"></label></td>
</tr>


<tr>
	<td>Image:</td>
	<td><input type="file" name="pic" id="pic"><label id="l_pic"></label></td>
</tr>

<tr>
	<td>security question:</td>
	<td><select id="Q" name="Q">
		<option value="">--select--</option>
		<option value="who is your favourite teacher?">who is your favourite teacher?</option>
		<option value="what is the name of you pet?">what is the name of you pet?</option>
		<option value="what is your mother's nick name?">what is your mother's nick name?</option>
		<option value="what is your father's birth date?">what is your father's birth date?</option>
		<option value="who is your favourite actor?">who is your favourite actor?</option>
		</select><br>Ans:<input type="text" name="ans" id="ans"><label id="l_security"></label></td>
</tr>

<tr>
	<td>Birthday:</td>
	<td><select id="month" name="month">
		<option value="">Month</option>
		<option value="01">January</option>
		<option value="02">February</option>
		<option value="03">March</option>
		<option value="04">April</option>
		<option value="05">May</option>
		<option value="06">June</option>
		<option value="07">July</option>
		<option value="08">August</option>
		<option value="09">September</option>
		<option value="10">October</option>
		<option value="11">November</option>
		<option value="12">December</option>
		</select>
		<select name="day" id="day">
		<?php for($i=1;$i<=31;$i++)  { ?>
		<option value="<?php echo $i ?>" ><?php echo $i ?></option>
		<?php } ?></select>
		
		<select name="year" id="year">
			<?php $year=2017;
			for($i=1;$i<20;$i++) { ?>
			<option value="<?php echo $year ?>"> <?php echo $year ?> </option>
			<?php 
				$year = $year-1; 
			} ?>
		</select>
		
		<label id="l_DOB"></label></td>
</tr>
		

<tr>
<td align="center"><input type="submit" value="Submit"></td>
<td align="center"><a hef="log.php"><button>Back</button></td>
</tr>


</table>
</form>
</body>
</html>