    <div class="col-sm-2 sidenav">
      <div class="well">
        <p><img src="logo/php-logo.gif" height="20p%"></p>
      </div>
      <div class="well">
        <p><img src="logo/mysql-logo.png" height="20p%"></p>
      </div>
    </div>
  </div>
</div>
<footer class="container-fluid text-center">
  <p>Open Source Local Website developed in php & mysql.</p>
</footer>

