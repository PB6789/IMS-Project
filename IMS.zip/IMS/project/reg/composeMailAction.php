<?Php
include "all.php";
session_start();

$tomail=$_POST["toId"];
$obj = new A();
$torec = $obj->fetchrecord($tomail);
$fromrec=$obj->fetchrecord($_SESSION['email']);
if($torec['uid'])
{
$toId=$torec['uid'];
$fromId=$fromrec['uid'];
$subject=$_POST["subject"];
$msg=$_POST["message"];
$date=date('Y-m-d');
$time=date('H:i:s');
//echo $toId.$fromId;
if($_FILES["pic"]["name"]!=""){
$path="uploaded/".rand(0,99)."_".time()."_".$_FILES["pic"]["name"];
$tmp_path=$_FILES["pic"]["tmp_name"];
move_uploaded_file($tmp_path,$path);
}
else{
	$path = NULL;
}

$compose=$obj->compose($toId,$fromId,$subject,$msg,$path,$date,$time);
}
else{
	
	echo "<script>alert('Email not Registered.')</script>";
	
	echo "<script>window.location.href='composeMail.php'</script>";
	exit;
}
if($compose)
{
	echo "<script>alert('your message has been sent')</script>";
	echo "<script>window.location.href='index.php'</script>";
	
}
else
{
	echo "<script>alert('message can not be send')</script>";
	echo "<script>window.location.href='composeMail.php'</script>";
}

?>