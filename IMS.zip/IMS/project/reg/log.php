<html>
<head>
<title>Login</title>
<script>

function validation()

{
	var user_name=document.getElementById("user_name").value;
	var a=user_name.indexOf("@");
	
		if(user_name=="" || a>-1 )
		{
			document.getElementById("l_user_name").innerHTML="invalid";
			document.getElementById("l_user_name").style.color="red";
			return false;
		}
		
	var password=document.getElementById("password").value;
	var f=password.length;
	
		 if(password=="" || f>6 || f<6 )
		{
			document.getElementById("l_password").innerHTML="invalid";
			document.getElementById("l_password").style.color="red";
			document.getElementById("l_valid").innerHTML="*password should contain six charecter"
			document.getElementById("l_valid").style.fontSize="12px";

			return false;
		}
		
}

</script>
</head>

<body align="center">

<form action="log_success.php" method="post" onsubmit="return validation()">

<table border="1" align="center">


	<th colspan="2" align="center">User Login</th>
	
<tr>
	<td>Username:</td>
	<td><input type="text" name="user_name" id="user_name" placeholder="enter your username">@imsmail.com <label id="l_user_name"></label></td>
</tr>

<tr>
	<td>Password:</td>
	<td><input type="password" name="password" id="password" placeholder="enter your password"> <label id="l_password"></label><br><label id="l_valid"></label></td>
</tr>

<tr>
	<td colspan="3" align="center"><input type="submit" value="Submit">
	<a href="form.php"><input type="button" value="New User?"></a>
	<a href="adminlogin.php"><input type="button" value="Admin Login"></a>
	</td>
</tr>	

</table>
</form>
<a href="forgotpassword.php">Forgot Password?</a>
</body>
</html>