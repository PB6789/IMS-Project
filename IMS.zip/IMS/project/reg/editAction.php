<?php
include "all.php";
session_start();
$s_id=$_SESSION['email'];					

	$user_name=$_SESSION['email'];
	$email=$_POST["email"];
	$first_name=$_POST["first_name"];
	$last_name=$_POST["last_name"];
	$gender=$_POST["gender"];
	$city=$_POST["city"];
	if($city=='other')
	{
	$city=$_POST["o_city"];
	}

	$address=$_POST["address"];
	$ph_no=$_POST["ph_no"];
	
	$obj=new A();
	$sql=$obj->update($user_name,$email,$first_name,$last_name,$gender,$city,$address,$ph_no,$s_id);
	
		if($sql)
		{
			echo "<script>alert('profile has been updated')</script>";
			echo "<script>window.location.href='editProfile.php'</script>";	
		}
		
		else
		{
			echo "<script>alert('error')</script>";
			echo "<script>window.location.href='editProfile.php'</script>";
		}
	
	?>