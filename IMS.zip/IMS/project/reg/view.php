<?php
session_start();
if(isset($_SESSION['email']))
{
	include "all.php";
	$uid = $_SESSION['email'];
	$id = $_REQUEST['id'];
	$str = explode('.',$_REQUEST['str']);
	$obj = new A();
	$row = $obj->fetchrecord();
	$qry = $obj->fetchmsg($row['uid'],$id,$str[0]);
	$to = $obj->fetchassoc($qry);
	
?>
<!DOCTYPE html>
<html lang="en">
<?php include "head.php"; ?>
<body>
<?php include "header.php"; ?>
<div class="col-sm-8 text-right"> 

<form>
<br>
<table>
<tr><td>From:</td><td><input type="text" size="100%" disabled value="<?php echo $str=='index.php'?$_SESSION['email']:$to[0]['user_name'];?>"/></td></tr>
<tr><td>To:</td><td><input type="text" size="100%" disabled value="<?php echo $str=='index.php'?$to[0]['user_name']:$_SESSION['email'];?>"/></td></tr>
<tr><td>Subject:</td><td><input type="text" size="100%" disabled value="<?php echo $to[0]['subject'];?>"/></td></tr>
<tr><td>Message:</td><td><textarea cols="100%" rows="15%" style="resize:none" disabled>
<?php
/*
echo "<pre>";
echo $str[0];
echo "</pre>";
*/
echo $to[0]['message'];
$rst = ($str[0]=='index'?$to[0]['user_name']:"");
?>
</textarea></td></tr>
<tr><td>Attachment:</td><td><a href="<?php echo $to[0]['file'];?>"><?php echo $to[0]['file']!=NULL?"Download":"";?></a></td></tr>
<tr><td colspan="2"><a href="composeMail.php?usr=<?php echo $rst;?>"><?php echo $str[0]=='index'?"Reply":"";?></a>&nbsp;&nbsp;&nbsp;
<?php

echo "   <a href=\"trashaction.php?id=".$id.'&str='.$str[0]."\">Move to Trash</a>    ";
?>
&nbsp;&nbsp;&nbsp;
Received on : <?php echo $to[0]['date'].' at '.$to[0]['time'] ?>

</td></tr>
</table>
</form>
</div>
	
<?php include "footer.php"; ?>
</body>
</html>

<?php
}
else{

	header('location:../index.php');
}

?>
